@extends('layouts.new-admin.app')
@section('content')
<div class="page-wrapper">
    <div class="page-content">
        <div class="card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <h5 class="mb-0">Contact Details</h5>
                    <a href="{{ route('contact-index') }}" class="btn btn-primary ms-auto">Back to List</a>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>Name:</strong></h6>
                        <p>{{ $data->firstname }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>Name:</strong></h6>
                        <p>{{ $data->lastname }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>Email:</strong></h6>
                        <p>{{ $data->email }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>City:</strong></h6>
                        <p>{{ $data->city }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>Mobile No.:</strong></h6>
                        <p>{{ $data->mobile_number }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-1"><strong>Mobile No.:</strong></h6>
                        <p>{{ $data->services }}</p>
                    </div>
                  
                    <div class="col-md-12">
                        <h6 class="mb-1"><strong>Created Date:</strong></h6>
                        <p>{{ $data->created_at->format('d M Y, h:i A') }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
